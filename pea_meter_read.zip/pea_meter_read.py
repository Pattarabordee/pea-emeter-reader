#!/usr/bin/env python3
"""Read-only collector for the local PEA BLE meter CLI.

The Swift CLI performs the BLE/DLMS work. This script only collects its
machine-readable @METER events and writes JSON/CSV evidence. Passwords are
never written to output files. This internal copy includes the project's
default credential mapping; remove it before sharing the source externally.
"""

import argparse
import csv
import getpass
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# รหัสตาม credential planner ของโปรเจกต์
# หากเผยแพร่ไฟล์นี้ ผู้ที่ได้รับไฟล์จะสามารถเห็นค่าเหล่านี้ได้
DEFAULT_METER_PASSWORD = "00454712"
METER_PASSWORDS = {
    "KFM-2022100275": "00000001",
    "PEA006500439407": "00454712",
    "6602781079": "00454712",
}


def iso_now():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description="อ่านค่า BLE/DLMS แบบ read-only")
    parser.add_argument("--target", required=True, help="ชื่อมิเตอร์ที่ประกาศผ่าน BLE")
    parser.add_argument("--duration", type=int, default=120, help="เวลาที่เก็บข้อมูลเป็นวินาที")
    parser.add_argument("--transport-ffe", action="store_true", help="ใช้กับมิเตอร์ที่ใช้ FFE0/FFE1/FFE2")
    parser.add_argument("--output", type=Path, default=Path("meter-read.json"))
    parser.add_argument("--password-env", default="METER_PASSWORD", help="ชื่อ environment ที่เก็บรหัสผ่าน")
    parser.add_argument("--prompt-password", action="store_true", help="ถามรหัสผ่านแทนค่า default ในโค้ด")
    parser.add_argument("--no-build", action="store_true", help="ไม่เรียก swift build ก่อนอ่าน")
    args = parser.parse_args()

    if args.duration < 1 or args.duration > 3600:
        parser.error("--duration ต้องอยู่ระหว่าง 1 ถึง 3600 วินาที")

    root = Path(__file__).resolve().parents[1]
    binary = root / ".build" / "debug" / "meter-scan"
    if not args.no_build:
        subprocess.run(["swift", "build"], cwd=root, check=True)
    if not binary.exists():
        raise SystemExit(f"ไม่พบตัวอ่าน: {binary}")

    password = os.environ.get(args.password_env)
    if args.prompt_password:
        password = getpass.getpass("DLMS meter password (hidden): ")
    elif not password:
        password = METER_PASSWORDS.get(args.target, DEFAULT_METER_PASSWORD)
    if not password or len(password.encode()) > 64:
        raise SystemExit("รหัสผ่านต้องมี 1–64 bytes")

    command = [str(binary), "--live", "--target", args.target]
    if args.transport_ffe:
        command.append("--transport-ffe")
    env = dict(os.environ)
    env["METER_PASSWORD"] = password

    started = iso_now()
    events = []
    samples = []
    started_monotonic = time.monotonic()
    process = subprocess.Popen(
        command, cwd=root, env=env, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, text=True, bufsize=1
    )
    try:
        for line in process.stdout:
            if time.monotonic() - started_monotonic >= args.duration:
                process.terminate()
                break
            line = line.rstrip("\n")
            if not line.startswith("@METER "):
                continue
            try:
                event = json.loads(line[7:])
            except json.JSONDecodeError:
                continue
            # Do not copy any password-like field if a future CLI adds one.
            event = {k: v for k, v in event.items()
                     if k.lower() not in {"password", "passwd", "secret", "token"}}
            event["collectedAt"] = iso_now()
            events.append(event)
            if event.get("type") == "sample":
                samples.append(event)
    finally:
        if process.poll() is None:
            process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()

    result = {
        "schemaVersion": 1,
        "readOnly": True,
        "meter": args.target,
        "startedAt": started,
        "finishedAt": iso_now(),
        "durationSeconds": args.duration,
        "transport": "FFE" if args.transport_ffe else "standard",
        "processExitCode": process.returncode,
        "sampleCount": len(samples),
        "events": events,
        "note": "ชื่อ BLE/UUID ไม่ใช่หลักฐานยืนยันรุ่นหรือหมายเลขมิเตอร์ ต้องเทียบกับมิเตอร์จริง; password ไม่ถูกบันทึกในผลลัพธ์",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    csv_path = args.output.with_suffix(".csv")
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=["meter", "timestamp", "voltage_V", "current_A", "voltageTime", "currentTime"])
        writer.writeheader()
        for sample in samples:
            writer.writerow({
                "meter": args.target,
                "timestamp": sample.get("timestamp"),
                "voltage_V": sample.get("voltage"),
                "current_A": sample.get("current"),
                "voltageTime": sample.get("voltageTime"),
                "currentTime": sample.get("currentTime"),
            })
    print(f"บันทึก {args.output} และ {csv_path} | samples={len(samples)} | exit={process.returncode}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("หยุดการอ่านโดยผู้ใช้", file=sys.stderr)
        raise SystemExit(130)
